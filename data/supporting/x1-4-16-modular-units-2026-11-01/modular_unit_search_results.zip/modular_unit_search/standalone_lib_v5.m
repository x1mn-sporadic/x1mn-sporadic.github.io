/* x12n_lib.m -- library for the van Hoeij "f - c" search for low-degree places on
   X_1(2,2n) (M = 2) and X_1(N) (M = 1).  Loaded by the drivers; not run directly.

   All arithmetic is done in the algebraic function field FA = AlgorithmicFunctionField of the
   plane model (the curve-function-field wrapper FldFunFracSch is 1000x slower for divisors).

   Provides:
     Setup(N, M)                 model, FA, b, c, E, P, Q, cusps (places of FA), moduli data
     CandidateUnits(S)           explicit modular units: b, Delta, x(kQ)-x(lQ), x(P+kQ)-x(lQ), ...
     UnitLattice(S, units)       valuation vectors at the cusps; LLL-reduced lattice
     UnitsOfDegreeAtMost(S, L, D) all lattice vectors of degree <= D
     UnitFromExponents(L, e)     the function Prod gens_i^e_i
     LowDegreeZeros(S, L, e, f, Cs, Degs, ~cache, ~res, ~timers)  non-cuspidal places of degree in Degs where f = c, c in Cs
     ReportPlace(S, pl, tag)     j-invariant, residue field, (E,P,Q) at a non-cuspidal place

   Conventions.  Models from mdmagma (Sutherland).  For M = 2:
     E: y^2 = x^3 + c x^2 + (1-b-c) b x,  P = (0,0) of order 2,  Q = (b,b) of order N.
   For M = 1 (Tate normal form):
     E: y^2 + (1-c) x y - b y = x^3 - b x^2,  Q = (0,0) of order N.
   A "unit" is a function whose divisor is supported on the cusps; its degree is the degree
   of its pole divisor = (1/2) sum_i deg(c_i) |v_{c_i}(f)|.                                  */

MDMAGMA_SPEC := "/home/fnajman/degree5_torsion/external/mdmagma/v2/mdmagma.spec";
MODELS_2_2N := "/home/fnajman/sporadic_2x2n/data/models_X1_m_n";   // mdmagma's files, wrapped lines joined
// Package attachment omitted: frozen standalone models are used.

SetupRec := recformat< N, M, X, C, FF, FA, toFA, b, c, E, P, Q, cusps, cuspdegs, r, ncusps, Delta, cuspfs, polefs, ratonly, K, zeta, filterdata, fmodel >;

// number of cusps of X_1(M, N) (N = order of Q, M | N): X_1(M,N) = X_{Gamma_1(N) meet Gamma_0(MN)}
// (conjugate Gamma_1(N) meet Gamma^0(M) by diag(M,1)); for M = 1 this is Gamma_1(N).
function NumberOfCuspsOfModel(N,M)
  data := AssociativeArray();
  data[<2,18>] := 24; data[<2,24>] := 40;
  data[<2,26>] := 36; data[<2,28>] := 48; data[<2,32>] := 56; data[<4,16>] := 40;
  return data[<M,N>];
end function;

// a prime p = 1 mod M, p not dividing N, at least Start
function GoodPrime(M, N, Start)
  p := Start;
  while not (IsPrime(p) and p mod M eq 1 and N mod p ne 0) do p +:= 1; end while;
  return p;
end function;

// the irreducible factors (as polynomials in the non-zero a-invariants) of the discriminant,
// evaluated at the curve's a-invariants: e.g. a3^3 (a1^3 - 27 a3) for y^2 + a1 xy + a3 y = x^3.
// Zeros(Delta) itself is slow on the larger models; the zeros/poles of the factors are cheap.
function DeltaFactors(E)
  ai := aInvariants(E); nz := [i : i in [1..5] | ai[i] ne 0];
  R := PolynomialRing(Rationals(), #nz);
  gen := [R!0 : i in [1..5]]; for k in [1..#nz] do gen[nz[k]] := R.k; end for;
  Eg := EllipticCurve([FieldOfFractions(R) | g : g in gen]);
  D := Numerator(FieldOfFractions(R)!Discriminant(Eg));
  fac := Factorization(D);
  return [ Evaluate(t[1], [ai[i] : i in nz]) : t in fac ];
end function;

SUTHERLAND_DIR := "/home/fnajman/sporadic_2x2n/refs/sutherland_X1mn";

// Sutherland's models of X_1(m, mn) for m >= 5 (math.mit.edu/~drew/X1mn.html): the file gives
// F = Q(zeta_m)^+ = Q(a), X(u,v) over F, t, x, E (Tate normal form in t with P = (0,0) of order
// mn) and Q = [x] (only the x-coordinate of the point of order m; its y-coordinate lies over
// Q(zeta_m)).  We work over K = Q(zeta_m) (or F_p containing zeta), a = zeta + zeta^-1, and
// recover y(Q) as a square root in the function field.  Returns the same data as mdmagma's
// _equation_X11: curve, E (a-invariants in FF), P (order m), Q (order mn), coordinates [t, x].
function SutherlandModel(M, N, Field, a)
  file := Sprintf("%o/X1_%o_%o.txt", SUTHERLAND_DIR, M, N);
  lines := Split(Read(file), "\n");
  getval := function(prefix)
    for l in lines do
      if #l ge #prefix and l[1..#prefix] eq prefix then
        v := l[#prefix+1..#l]; v := Split(v, ";")[1]; return v;
      end if;
    end for;
    error "line not found:", prefix;
  end function;
  if exists{l : l in lines | #l ge 4 and l[1..4] eq "F<a>"} then
    pol := eval Split(getval("F<a>:=NumberField(PolynomialRing(Rationals())!"), ")")[1];   // coefficient list
    assert &+[pol[i]*a^(i-1) : i in [1..#pol]] eq 0;
  end if;
  A<u,v> := AffineSpace(Field, 2);
  Xpol := eval getval("X := ");
  C := Curve(A, Xpol);
  FF := FunctionField(C);
  u := FF.1; v := FF.2;
  t := eval getval("t := ");
  x := eval getval("x := ");
  R := FF;                                   // "P := [R!0,0]" in the file
  E := eval getval("E := ");
  E := [FF!e : e in E];
  return ProjectiveClosure(C), E, [FF | x], [FF | 0, 0], [FF | t, x];
end function;

// Setup.  Field: the base field (Q, or Q(zeta_M) for M >= 3, or GF(p) with p = 1 mod M for the
// mod-p computations; then Zeta must be the reduction of the chosen zeta_M).
function Setup(N,M : Field:=Rationals(), Zeta:=0, RationalCuspsOnly:=false, NoCusps:=false)
  if M ge 3 and Type(Field) eq FldRat then Field:=CyclotomicField(M); end if;
  if M eq 4 then
    if Zeta cmpeq 0 then Zeta:=Field.1; end if;
    i:=Zeta; assert i^2 eq -1;
  end if;
  A<u,v>:=AffineSpace(Field,2);
  file:=Sprintf("./models/X1_%o_%o.txt",M,N);
  for line in Split(Read(file),"\n") do
    if #line eq 0 or not ":=" in line then continue; end if;
    kv:=Split(line,":="); key:=Trim(kv[1]); val:=Split(kv[2],";")[1];
    if key in {"X","Xi"} then Xpol:=eval val;
    elif key eq "q" then q:=eval val;
    elif key eq "t" then t:=eval val;
    elif key eq "E" then Ecoef:=eval val;
    elif key eq "P" then Qxy:=eval val;
    elif key eq "Q" then Pxy:=eval val;
    end if;
  end for;
  printf "MODEL_LOADED M=%o N=%o cpu=%o\n",M,N,Cputime();
  C:=ProjectiveClosure(Curve(A,Xpol)); FF:=FunctionField(C);
  printf "CURVE_FIELD_READY M=%o N=%o cpu=%o\n",M,N,Cputime();
  FA,toFA:=AlgorithmicFunctionField(FF);
  printf "ALGORITHMIC_FIELD_READY M=%o N=%o cpu=%o\n",M,N,Cputime();
  if M eq 2 then
    bexpr:=(t+1)*(q*t+1)/t^2;cexpr:=(t^2-2*q*t-2)/t^2;
    b:=toFA(FF!bexpr);c:=toFA(FF!cexpr);
    rawfs:=[bexpr,1-bexpr-cexpr,4*bexpr^2+4*bexpr*cexpr-4*bexpr+cexpr^2];
    E:=EllipticCurve([0,c,0,(1-b-c)*b,0]);P:=E![0,0];Q:=E![b,b];
  else
    b:=toFA(FF!q);c:=toFA(FF!t);
    E:=EllipticCurve([toFA(FF!a):a in Ecoef]);
    P:=E![toFA(FF!x):x in Pxy];Q:=E![toFA(FF!x):x in Qxy];
  end if;
  printf "ELLIPTIC_MODEL_READY M=%o N=%o cpu=%o\n",M,N,Cputime();
  if not NoCusps then assert IsZero(M*P) and IsZero(N*Q);end if;
  printf "LEVEL_CHECK_READY M=%o N=%o cpu=%o\n",M,N,Cputime();
  Delta:=Discriminant(E); ncusps:=NumberOfCuspsOfModel(N,M);
  if M eq 2 then fs:=[b,1-b-c,4*b^2+4*b*c-4*b+c^2];polefs:=[];
  else fs:=DeltaFactors(E);polefs:=[a:a in aInvariants(E)|a ne 0];end if;
  cusps:=[];
  if not NoCusps then
    if M eq 2 and IsFinite(Field) then
      factors:=[];
      for ff in rawfs do
        for fac in Factorization(Numerator(ff)) cat Factorization(Denominator(ff)) do
          if fac[1] notin factors then Append(~factors,fac[1]);end if;
        end for;
      end for;
      printf "CUSP_FACTORS M=%o N=%o count=%o cpu=%o\n",M,N,#factors,Cputime();
      for ff in factors do
        for pl in Zeros(toFA(FF!ff)) do if pl notin cusps then Append(~cusps,pl);end if;end for;
      end for;
      for ff in [toFA(FF.1),toFA(FF.2)] do
        for pl in Poles(ff) do if pl notin cusps then Append(~cusps,pl);end if;end for;
      end for;
      jj:=jInvariant(E);cusps:=[pl:pl in cusps|Valuation(jj,pl) lt 0];
      printf "CUSP_SUPPORT M=%o N=%o total=%o expected=%o cpu=%o\n",M,N,&+[Degree(pl):pl in cusps],ncusps,Cputime();
    else
      for f in fs do for pl in Zeros(f) cat Poles(f) do if pl notin cusps then Append(~cusps,pl);end if;end for;end for;
      for f in polefs do for pl in Poles(f) do if pl notin cusps then Append(~cusps,pl);end if;end for;end for;
    end if;
    assert &+[Degree(pl):pl in cusps] eq ncusps;
  end if;
  return rec<SetupRec|N:=N,M:=M,X:=0,C:=C,FF:=FF,FA:=FA,toFA:=toFA,b:=b,c:=c,E:=E,P:=P,Q:=Q,cusps:=cusps,cuspdegs:=[Degree(pl):pl in cusps],r:=#cusps,ncusps:=ncusps,Delta:=Delta,cuspfs:=fs,polefs:=polefs,ratonly:=true,K:=Field,zeta:=Zeta,filterdata:=[* *],fmodel:=false>;
end function;

// is the place a cusp?  (S`cusps may hold only the rational cusps)
function IsCuspidalPlace(S, pl)
  if pl in S`cusps then return true; end if;
  if not S`ratonly then return false; end if;
  return exists{f : f in S`cuspfs | Valuation(f, pl) ne 0} or exists{f : f in S`polefs | Valuation(f, pl) lt 0};
end function;

// x-coordinates x(kQ), k = 1..floor(N/2), and (M = 2) x(P + kQ), k = 0..floor(N/2)
function XCoords(S)
  N := S`N; Q := S`Q; h := N div 2;
  xs := [];  R := Q;
  for k in [1..h] do assert R[3] eq 1; Append(~xs, R[1]); R +:= Q; end for;
  xps := [];
  if S`M eq 2 then
    R := S`P;
    for k in [0..h] do assert R[3] eq 1; Append(~xps, R[1]); R +:= Q; end for;
  end if;
  return xs, xps;
end function;

// explicit modular units with a label each (checked later; non-units are dropped)
function CandidateUnits(S)
  if S`fmodel then
    // F-model: P = (0,0) of order M in E(FA); Q of order N with y over the quadratic extension
    // (or in FA over F_p).  The conjugation of that extension is Q -> -Q, so x(kQ) lies in FA.
    // Units on the F-model curve: differences of x-coordinates of points in FA (kQ, aP), and the
    // products over the conjugate pairs for the mixed points aP + kQ (a = 1..M-1, k = 1..N/2).
    N := S`N; M := S`M; h := N div 2; Q := S`Q; P := S`P; FA := S`FA;
    FQ := Parent(Q[1]); split := FQ eq FA;
    Nm := func< x | split select FA!x else FA!Norm(x) >;   // only used on invariant elements when split
    EQ := Curve(Q); PQ := EQ!P;                        // P on E over the field of Q
    inv := []; invlab := [];                           // points with x in FA: kQ (k <= N/2), aP (a <= M/2)
    R := Q;
    for k in [1..h] do assert R[3] eq 1; Append(~inv, FA!R[1]); Append(~invlab, Sprintf("%oQ", k)); R +:= Q; end for;
    R := P;
    for a in [1..M div 2] do assert R[3] eq 1; Append(~inv, R[1]); Append(~invlab, Sprintf("%oP", a)); R +:= P; end for;
    mixed := [* *]; mixedc := [* *]; mixlab := [];      // aP + kQ and the conjugates aP - kQ
    for a in [1..M-1] do
      R := a*PQ + Q; Rc := a*PQ - Q;
      for k in [1..h] do
        assert R[3] eq 1 and Rc[3] eq 1;
        Append(~mixed, R[1]); Append(~mixedc, Rc[1]); Append(~mixlab, Sprintf("%oP+%oQ", a, k));
        R +:= Q; Rc -:= Q;
      end for;
    end for;
    units := [* *];
    Append(~units, <"Delta", S`Delta>);
    for i in [1..#inv] do for j in [i+1..#inv] do
      Append(~units, <Sprintf("x(%o)-x(%o)", invlab[i], invlab[j]), inv[i] - inv[j]>);
    end for; end for;
    for i in [1..#mixed] do for j in [1..#inv] do
      Append(~units, <Sprintf("Nm(x(%o)-x(%o))", mixlab[i], invlab[j]), FA!((mixed[i] - inv[j])*(mixedc[i] - inv[j]))>);
    end for; end for;
    for i in [1..#mixed] do for j in [i+1..#mixed] do
      Append(~units, <Sprintf("Nm(x(%o)-x(%o))", mixlab[i], mixlab[j]), FA!((mixed[i] - mixed[j])*(mixedc[i] - mixedc[j]))>);
    end for; end for;
    return units;
  end if;
  if S`M ge 3 then
    // representatives of the non-zero elements of <P, Q> = Z/M x Z/N up to sign:
    // aP + kQ with a = 0 (k = 1..N/2), 0 < a < M/2 (k = 0..N-1), a = M/2 (k = 0..N/2)
    N := S`N; M := S`M; P := S`P; Q := S`Q;
    pts := []; labels := [];
    for a in [0..M div 2] do
      if a eq 0 then ks := [1..N div 2];
      elif 2*a lt M then ks := [0..N-1];
      else ks := [0..N div 2]; end if;
      R := a*P;
      for k in ks do
        T := R + k*Q;
        assert T[3] eq 1;
        Append(~pts, T[1]); Append(~labels, Sprintf("%oP+%oQ", a, k));
      end for;
    end for;
    units := [* *];
    Append(~units, <"Delta", S`Delta>);
    for i in [1..#pts] do for j in [i+1..#pts] do
      Append(~units, <Sprintf("x(%o)-x(%o)", labels[i], labels[j]), pts[i] - pts[j]>);
    end for; end for;
    return units;
  end if;
  xs, xps := XCoords(S); h := S`N div 2;
  units := [* *];
  Append(~units, <"b", S`b>); Append(~units, <"c", S`c>);
  Append(~units, <"Delta", S`Delta>);
  if S`M eq 2 then
    Append(~units, <"1-b-c", 1 - S`b - S`c>);                            // a4 / b
    Append(~units, <"disc2", 4*S`b^2 + 4*S`b*S`c - 4*S`b + S`c^2>);      // disc of x^2+cx+(1-b-c)b
    for k in [1..h] do Append(~units, <Sprintf("x(%oQ)", k), xs[k]>); end for;   // = x(kQ) - x(P)
    for k in [1..h] do if xps[k+1] ne 0 then Append(~units, <Sprintf("x(P+%oQ)", k), xps[k+1]>); end if; end for;
  end if;
  for k in [1..h] do for l in [k+1..h] do
    Append(~units, <Sprintf("x(%oQ)-x(%oQ)", k, l), xs[k] - xs[l]>);
  end for; end for;
  if S`M eq 2 then
    for k in [1..h] do for l in [1..h] do
      Append(~units, <Sprintf("x(P+%oQ)-x(%oQ)", k, l), xps[k+1] - xs[l]>);
    end for; end for;
    for k in [1..h] do for l in [k+1..h] do
      Append(~units, <Sprintf("x(P+%oQ)-x(P+%oQ)", k, l), xps[k+1] - xps[l+1]>);
    end for; end for;
  end if;
  return units;
end function;

// Valuation vector at the cusps and whether div(f) is supported on the cusps.  Never call
// Support(Divisor(f)) here: for a non-unit (e.g. c) it constructs a huge non-cuspidal place
// (336 s on 2n = 20); Valuation(f, cusp) and Degree(f) are cheap.  Sets of places are also to be
// avoided (hashing places is extremely slow); use sequences and Index.
// (Degree(f) is itself slow for the bigger candidates -- 6 s each on X_1(25) -- so the candidate
// loop only checks that the cuspidal part has degree 0; the full check is done for the chosen
// generators only, see UnitLattice.)
function CuspValuations(S, f : Full := false)
  vals := [Valuation(f, cp) : cp in S`cusps];
  pos := &+[ Integers() | vals[i]*S`cuspdegs[i] : i in [1..S`r] | vals[i] gt 0 ];
  neg := &+[ Integers() | -vals[i]*S`cuspdegs[i] : i in [1..S`r] | vals[i] lt 0 ];
  if pos ne neg or pos eq 0 then return vals, false; end if;
  if not Full then return vals, true; end if;
  return vals, Degree(f) eq pos;      // all poles at cusps => all zeros at cusps too (degrees match)
end function;

/* ---- cusp valuations of the candidate units computed over F_p --------------------------------
   Over Q, Valuation(f, cusp) costs up to 12 s at the deep rational cusps (2n = 22: ~45 s per
   candidate, hours in total).  For p not dividing 2N the candidate units are invertible on
   Y_1(2,2n) over Z[1/2N] and the cuspidal subscheme is finite etale, so div(f) reduces to
   div(f mod p) and v_C(f) = v_{C'}(f mod p) for every F_p-cusp C' in the reduction of C.
   F_p-cusps are matched to Q-cusps by the valuations of a few reference functions
   (b, c, 1-b-c, disc2, u, v, and x(kQ) as needed); the matching is verified by the degrees.  */
REF_LABELS := ["b", "c", "1-b-c", "disc2", "u", "v"];

function RefFunctions(S)
  if S`fmodel then
    return [S`b, S`c, S`Delta, S`FA.1, S`FA!(BaseField(S`FA).1)] cat [a : a in aInvariants(S`E) | a ne 0];
  end if;
  if S`M ge 3 then
    return [S`b, S`c, S`Delta, S`FA.1, S`FA!(BaseField(S`FA).1)] cat [a : a in aInvariants(S`E) | a ne 0];
  end if;
  refs := [S`b, S`c, 1 - S`b - S`c, 4*S`b^2 + 4*S`b*S`c - 4*S`b + S`c^2, S`FA.1, S`FA!(BaseField(S`FA).1)];
  return refs;
end function;

// signatures of the Q-cusps for the reference functions plus extra unit labels until unique
function CuspSignaturesQ(S, units)
  refs := RefFunctions(S); labels := (S`M ge 3 or S`fmodel) select [Sprintf("ref%o", i) : i in [1..#refs]] else REF_LABELS;
  sigs := [ [Valuation(f, C) : f in refs] : C in S`cusps ];
  extra := 0;
  while #Seqset(sigs) lt S`r do
    extra +:= 1;
    if extra gt #units then error "cannot separate the cusps by signatures"; end if;
    u := units[extra];
    if u[1] in labels then continue; end if;
    Append(~labels, u[1]);
    for i in [1..S`r] do Append(~sigs[i], Valuation(u[2], S`cusps[i])); end for;
  end while;
  return sigs, labels;
end function;

// valuation vectors (at the Q-cusps, in S`cusps order) of all candidate units, via F_p
// reduction of the base field K at a degree-1 prime above p (K = Q: the obvious map)
function ResidueMap(K, p)
  if Type(K) eq FldRat then return map< K -> GF(p) | x :-> GF(p)!x >; end if;
  OK := MaximalOrder(K);
  for dp in Decomposition(OK, p) do
    if Degree(dp[1]) eq 1 then Fq, red := ResidueClassField(dp[1]); return map< K -> GF(p) | x :-> GF(p)!red(x) >; end if;
  end for;
  error "no degree-1 prime above", p;
end function;

function CandidateValuationsModP(S,units,sigsQ,siglabels,p : CandGen:=CandidateUnits)
  cachepath:=Sprintf("./cusp_cache_%o_%o_p%o.txt",S`M,S`N,p);
  if S`M eq 2 and p eq 3 and S`N in {26,28,32} then
    data:=eval Read(cachepath);
    assert data[2] eq [u[1]:u in units];
    assert &+data[1] eq S`ncusps;
    printf "CUSP_CACHE_LOADED %o\n",cachepath;
    return data[3],data[4],0,data[1];
  end if;
  if S`M ge 3 then red:=ResidueMap(S`K,p);Sp:=Setup(S`N,S`M:Field:=GF(p),Zeta:=red(S`zeta));
  else Sp:=Setup(S`N,S`M:Field:=GF(p));end if;
  unitsp:=CandGen(Sp);assert [u[1]:u in unitsp] eq [u[1]:u in units];
  weights:=[Degree(pl):pl in Sp`cusps];vecs:=[];oks:=[];
  for u in unitsp do
    if u[2] eq 0 then Append(~vecs,[0:i in weights]);Append(~oks,false);continue;end if;
    w:=[Valuation(u[2],pl):pl in Sp`cusps];
    pos:=&+[Integers()|w[i]*weights[i]:i in [1..#w]|w[i] gt 0];
    neg:=&+[Integers()|-w[i]*weights[i]:i in [1..#w]|w[i] lt 0];
    Append(~vecs,w);Append(~oks,pos eq neg and pos gt 0 and Degree(u[2]) eq pos);
  end for;
  return vecs,oks,Sp,weights;
end function;

LatRec := recformat< gens, genlabels, V, B, T, basisfuns, Lat, pl0 >;
// gens: a generating set of the Z-span of the cusp-valuation vectors of all cuspidal candidates
// (chosen greedily, smallest degree first); V: their valuation vectors (rows); B = T*V an
// LLL-reduced basis of the Z-span (rows); basisfuns[j]: the function with divisor B[j],
// normalised so that basisfuns[j] = Prod gens_i^T[j,i] exactly.  Lat: the lattice with basis B
// and inner product weighted by the cusp degrees.

// a non-cuspidal place used to fix normalisations: the first zero of (base variable - a)
function NormalisationPlace(S)
  v := BaseField(S`FA).1;
  for a in [2, 3, 5, 7, 11, 13, 17, 19, 23, 29] do
    for pl in Zeros(S`FA!(v - a)) do
      if not IsCuspidalPlace(S, pl) then return pl; end if;
    end for;
  end for;
  error "no normalisation place found";
end function;

// the function with divisor sum_i w[i] * cusps[i] (must be principal), Magma-normalised
function FunctionWithCuspidalDivisor(S, w)
  D := &+[ w[i]*(1*S`cusps[i]) : i in [1..S`r] ];
  V, m := RiemannRochSpace(-D);
  assert Dimension(V) eq 1;
  return m(V.1);
end function;

function UnitLattice(S, units : Verbose := true, ModP := 0, DegreeCheck := false, CandGen := CandidateUnits)
  t0 := Cputime();
  vecs := []; cands := [* *]; labels := []; nonunits := []; degs := [];
  if ModP ne 0 then
    sigsQ, siglabels := CuspSignaturesQ(S, units);
    if Verbose then printf "UNITS cusp signatures over Q from %o, time %o\n", siglabels, Cputime(t0); end if;
    allvecs, oks := CandidateValuationsModP(S, units, sigsQ, siglabels, ModP : CandGen := CandGen);
    if Verbose then printf "UNITS valuations of %o candidates computed over F_%o, time %o\n", #units, ModP, Cputime(t0); end if;
  end if;
  for k in [1..#units] do
    u := units[k];
    if u[2] eq 0 then continue; end if;
    if ModP ne 0 then vals := allvecs[k]; ok := oks[k];
    else vals, ok := CuspValuations(S, u[2]); end if;
    if not ok then Append(~nonunits, u[1]); continue; end if;
    Append(~vecs, vals); Append(~cands, u[2]); Append(~labels, u[1]);
    Append(~degs, (&+[Abs(vals[i])*S`cuspdegs[i] : i in [1..S`r]]) div 2);
  end for;
  if Verbose then printf "UNITS %o cuspidal candidates of %o, degrees %o..%o; non-units skipped: %o; time %o\n", #cands, #units, Min(degs), Max(degs), nonunits, Cputime(t0); end if;
  // greedy generating set of the Z-span, smallest degrees first
  order := Sort([1..#cands], func<i, j | degs[i] - degs[j]>);
  gens := [* *]; genlabels := []; genvecs := []; Lat0 := 0;
  for idx in order do
    v := Vector(Integers(), vecs[idx]);
    if #genvecs gt 0 and v in Lat0 then continue; end if;
    Append(~genvecs, vecs[idx]); Append(~gens, cands[idx]); Append(~genlabels, labels[idx]);
    Lat0 := Lattice(Matrix(Integers(), genvecs));
  end for;
  // optional full unit check (Degree) for the generators: ~34 s per generator on 2n = 24, so off
  // by default; the candidates are units by construction (torsion points stay distinct on Y).
  if DegreeCheck then
    for k in [1..#gens] do
      vals, ok := CuspValuations(S, gens[k] : Full := true);
      if not ok then printf "UNITS_ERROR generator %o is not a unit (Degree check failed)\n", genlabels[k]; end if;
      assert ok;
    end for;
  end if;
  V := Matrix(Integers(), genvecs);
  B, T := LLL(V : Delta := 0.999);
  nz := [i : i in [1..Nrows(B)] | not IsZero(B[i])];
  B := Matrix(Integers(), [Eltseq(B[i]) : i in nz]); T := Matrix(Integers(), [Eltseq(T[i]) : i in nz]);
  assert B eq T*V;
  rk := Nrows(B);
  if Verbose then
    printf "UNITS generating set of %o units (%o), Z-span of rank %o (#cusporbits-1 = %o), max |T| = %o, time %o\n", #gens, genlabels, rk, S`r - 1, Max([Abs(x) : x in Eltseq(T)]), Cputime(t0);
  end if;
  // basis functions via Riemann-Roch, normalised against the canonical products at pl0
  pl0 := NormalisationPlace(S);
  genvals := [* Evaluate(f, pl0) : f in gens *];
  basisfuns := [* *];
  for j in [1..rk] do
    tj := Cputime();
    g := FunctionWithCuspidalDivisor(S, Eltseq(B[j]));
    if Verbose and Cputime(tj) gt 30 then printf "UNITS basis function %o/%o: Riemann-Roch %o s\n", j, rk, Cputime(tj); end if;
    target := Parent(genvals[1])!1;
    for i in [1..#gens] do if T[j,i] ne 0 then target *:= genvals[i]^T[j,i]; end if; end for;
    ratio := Evaluate(g, pl0) / target;
    ok, r := IsCoercible(Rationals(), ratio);
    assert ok;
    Append(~basisfuns, g / r);
  end for;
  if Verbose then printf "UNITS basis functions built (Riemann-Roch + normalisation), degrees %o, time %o\n", [ (&+[Abs(B[j,i])*S`cuspdegs[i] : i in [1..S`r]]) div 2 : j in [1..rk] ], Cputime(t0); end if;
  W := DiagonalMatrix(Integers(), S`cuspdegs);
  Lat := LatticeWithBasis(B, W);
  return rec< LatRec | gens := gens, genlabels := genlabels, V := V, B := B, T := T, basisfuns := basisfuns, Lat := Lat, pl0 := pl0 >;
end function;

// degree of the unit with valuation vector w
function UnitDegree(S, w)
  return (&+[ Abs(w[i])*S`cuspdegs[i] : i in [1..S`r] ]) div 2;
end function;

/* ---- unit lattice from pairwise ratios of the candidates (no Riemann-Roch) -------------------
   The candidates x(A)-x(B) have large degree (their poles come from the poles of x at the deep
   cusps), but ratios (x(A)-x(B))/(x(A)-x(C)) are units of minimal degree (6 on X_1(2,18),
   8 on X_1(2,20)), and a greedy generating set of such ratios spans the full lattice with an
   LLL transformation of size <= ~20 (logs/test_ratios_*.log), so every basis function is a
   short product of ratios -- exact, no normalisation needed.  Riemann-Roch (used before) took
   up to > 45 min per basis function on 2n = 24.                                                */
LatRec := recformat< cands, candvecs, labels, genpairs, gens, V, B, T, basisfuns, Lat >;

function UnitLatticeR(S, units : Verbose := true, ModP := 10007, CandGen := CandidateUnits)
  t0 := Cputime();
  sigsQ, siglabels := CuspSignaturesQ(S, units);
  if Verbose then printf "UNITS cusp signatures over Q from %o, time %o\n", siglabels, Cputime(t0); end if;
  allvecs, oks, Sp, cuspdegs := CandidateValuationsModP(S, units, sigsQ, siglabels, ModP : CandGen := CandGen);
  S`cuspdegs := cuspdegs; S`r := #cuspdegs;
  if Verbose then printf "UNITS valuations of %o candidates over F_%o: %o cusp orbits/classes of degrees %o (%o as Q-places), time %o\n", #units, ModP, S`r, cuspdegs, #S`cusps, Cputime(t0); end if;
  cands := [* *]; candvecs := []; labels := []; nonunits := [];
  for k in [1..#units] do
    if oks[k] then Append(~cands, units[k][2]); Append(~candvecs, allvecs[k]); Append(~labels, units[k][1]);
    else Append(~nonunits, units[k][1]); end if;
  end for;
  LAll := Lattice(Matrix(Integers(), candvecs));
  rk := Rank(LAll);
  // pool: candidates and pairwise ratios (vectors), sorted by degree
  pool := [];
  for i in [1..#cands] do
    Append(~pool, <UnitDegree(S, candvecs[i]), i, 0>);
    for j in [i+1..#cands] do
      w := [candvecs[i][k] - candvecs[j][k] : k in [1..S`r]];
      if not IsZero(Vector(w)) then Append(~pool, <UnitDegree(S, w), i, j>); end if;
    end for;
  end for;
  Sort(~pool, func<a, b | a[1] - b[1]>);
  genpairs := []; genvecs := []; Lat0 := 0;
  for t in pool do
    w := t[3] eq 0 select candvecs[t[2]] else [candvecs[t[2]][k] - candvecs[t[3]][k] : k in [1..S`r]];
    v := Vector(Integers(), w);
    if #genvecs gt 0 and v in Lat0 then continue; end if;
    Append(~genvecs, w); Append(~genpairs, <t[2], t[3]>);
    Lat0 := Lattice(Matrix(Integers(), genvecs));
    if Rank(Lat0) eq rk and Index(LAll, Lat0) eq 1 then break; end if;
  end for;
  gens := [* t[2] eq 0 select cands[t[1]] else cands[t[1]] / cands[t[2]] : t in genpairs *];
  V := Matrix(Integers(), genvecs);
  B, T := LLL(V : Delta := 0.999);
  nz := [i : i in [1..Nrows(B)] | not IsZero(B[i])];
  B := Matrix(Integers(), [Eltseq(B[i]) : i in nz]); T := Matrix(Integers(), [Eltseq(T[i]) : i in nz]);
  assert B eq T*V;
  if Verbose then
    printf "UNITS %o cuspidal candidates (non-units: %o); Z-span rank %o (#orbits-1 = %o); %o ratio generators of degrees %o, index %o; LLL basis degrees %o, max|T| = %o, time %o\n", #cands, nonunits, rk, S`r - 1, #gens, [UnitDegree(S, w) : w in genvecs], Index(LAll, Lat0), [UnitDegree(S, Eltseq(B[j])) : j in [1..Nrows(B)]], Max([Abs(x) : x in Eltseq(T)]), Cputime(t0);
  end if;
  basisfuns := [* *];
  for j in [1..Nrows(B)] do
    f := S`FA!1;
    for k in [1..#gens] do if T[j,k] ne 0 then f *:= gens[k]^T[j,k]; end if; end for;
    Append(~basisfuns, f);
  end for;
  if Verbose then printf "UNITS basis functions built as products, time %o\n", Cputime(t0); end if;
  W := DiagonalMatrix(Integers(), S`cuspdegs);
  Lat := LatticeWithBasis(B, W);
  L := rec< LatRec | cands := cands, candvecs := candvecs, labels := labels, genpairs := genpairs, gens := gens, V := V, B := B, T := T, basisfuns := basisfuns, Lat := Lat >;
  return L, S;
end function;


// Short vectors of the unit lattice: all nonzero vectors (up to sign) with weighted L2 norm
// sum_i deg_i w_i^2 <= Bound, as pairs <w, e> (e = coordinates w.r.t. the reduced basis),
// sorted by degree.  (The L2 ball of radius 2D contains every unit of degree <= D, but it is
// far too big to enumerate for D beyond ~6; in practice we take what a moderate L2 bound gives
// and treat it as a supply of small "random" units, as van Hoeij did.)
function ShortUnits(S, L, Bound : MaxCount := 10^6)
  sv := ShortVectors(L`Lat, Bound : Max := MaxCount);
  res := [];
  for t in sv do
    w := Eltseq(t[1]);
    e := Coordinates(L`Lat, t[1]);
    Append(~res, <w, e>);
  end for;
  Sort(~res, func<a, b | UnitDegree(S, a[1]) - UnitDegree(S, b[1])>);
  return res;
end function;

function UnitsOfDegreeAtMost(S, L, D)
  return [t : t in ShortUnits(S, L, (2*D)^2) | UnitDegree(S, t[1]) le D];
end function;

// the unit with coordinates e w.r.t. the reduced basis B
function UnitFromExponents(L, e)
  f := Parent(L`basisfuns[1])!1;
  for i in [1..#e] do if e[i] ne 0 then f *:= L`basisfuns[i]^e[i]; end if; end for;
  return f;
end function;

// ---- mod-p filter: can the fiber of g = f - c contain a place of degree <= Dmax above the
// irreducible factor t of Q[v]?  Such a place P has residue field Q(v0, u0) with [Q(v0,u0):Q(v0)]
// = r <= Dmax/deg(t); reducing modulo a prime p of good reduction where the denominators of the
// coefficients do not vanish, u0 mod p is a common root of F(U, v0) and G(U, v0) over F_{p^s}
// (v0 mod p a root of an irreducible factor of degree s of t mod p) of degree <= r over F_{p^s}.
// If some prime shows no such common root, the place does not exist (no false negatives).
FILTER_NPRIMES := 6;   // a place of degree D > max(Degs) has a Frobenius cycle of a wanted length r with probability ~1/r per prime

// filter primes for the base field K of S: p = 1 mod M (so that K has a degree-1 prime above p),
// with the residue maps K -> F_p; computed once and cached in S`filterdata
function FilterData(S)
  data := [* *]; p := 10007;
  while #data lt 20 do
    p := GoodPrime(S`M, S`N, p + 1);
    Append(~data, <p, ResidueMap(S`K, p)>);
  end while;
  return data;
end function;

// reduce a polynomial over K (or K(v)-numerator) modulo p via red; false if a coefficient has p
// in its denominator
function ReducePoly(t, Rp, red)
  cs := [];
  for a in Coefficients(t) do
    ok, r := IsCoercible(Rationals(), a);
    if ok then
      if Denominator(r) mod Characteristic(Rp) eq 0 then return false, 0; end if;
      Append(~cs, Rp!(BaseRing(Rp)!r));
    else
      try x := red(a); catch e return false, 0; end try;
      Append(~cs, Rp!(BaseRing(Rp)!x));
    end if;
  end for;
  return true, Polynomial(BaseRing(Rp), cs);
end function;

function PassesModPFilter(S, t, g, Degs)
  // Degs: the set of place degrees we are after; a place above t has degree e*r
  e := Degree(t); rs := {d div e : d in Degs | d mod e eq 0};
  if #rs eq 0 then return false; end if;
  rmax := Max(rs);
  Fpol := DefiningPolynomial(S`FA);            // in K[v][U]
  cF := Coefficients(Fpol);                     // in K[v]
  cg := Eltseq(g);                              // in K(v), w.r.t. powers of FA.1
  ntested := 0;
  for pd in S`filterdata do
    p := pd[1]; red := pd[2];
    Fp := GF(p); Rp := PolynomialRing(Fp);
    ok, tp := ReducePoly(t, Rp, red);
    if not ok or Degree(tp) ne Degree(t) or not IsSquarefree(tp) then continue; end if;
    fac := Factorization(tp); q := fac[1][1]; sdeg := Degree(q);
    if sdeg eq 1 then Fq := Fp; vb := -Coefficient(q, 0)/Coefficient(q, 1);   // ext<Fp|linear>.1 is NOT a root
    else Fq := ext< Fp | q >; vb := Fq.1; end if;
    assert Evaluate(q, vb) eq 0;
    // evaluate the coefficients at vb
    good := true;
    Fu := PolynomialRing(Fq)!0; Gu := PolynomialRing(Fq)!0;
    for i in [1..#cF] do
      ok, ci := ReducePoly(cF[i], Rp, red); if not ok then good := false; break; end if;
      Fu +:= Evaluate(ci, vb) * PolynomialRing(Fq).1^(i-1);
    end for;
    if not good or Degree(Fu) lt Degree(Fpol) or not IsSquarefree(Fu) then continue; end if;
    for i in [1..#cg] do
      ok1, ni := ReducePoly(Numerator(cg[i]), Rp, red); ok2, di := ReducePoly(Denominator(cg[i]), Rp, red);
      if not (ok1 and ok2) then good := false; break; end if;
      dv := Evaluate(di, vb); if dv eq 0 then good := false; break; end if;
      Gu +:= (Evaluate(ni, vb) / dv) * PolynomialRing(Fq).1^(i-1);
    end for;
    if not good then continue; end if;
    // Gu = 0 means f - c vanishes on the whole fibre over this v-value (f is a Moebius function
    // of v, say); the places in question are then those of the fibre itself, i.e. of Fu.
    h := Gu eq 0 select Fu else GCD(Fu, Gu);
    if Degree(h) eq 0 then return false; end if;
    // A characteristic-zero residue extension may split on reduction.
    // Its total residue degree survives; requiring an irreducible factor of that degree is invalid.
    if Degree(h) lt Min(rs) then return false; end if;
    ntested +:= 1;
    if ntested ge FILTER_NPRIMES then return true; end if;
  end for;
  return true;                                   // could not decide: fall through to the exact test
end function;

// cache: factor (as string) -> list of <place, [g_j(place)]> for the non-cuspidal places above
// the factor, with the values of the basis units there (passed by reference: Magma functions
// cannot modify outer variables).  Testing f(place) = c is then a product in the residue field.
procedure PlacesAboveFactor(S, L, t, g, Degs, ~cache, ~pls)
  key := Sprint(t);
  if IsDefined(cache, key) then pls := cache[key]; return; end if;
  pls := [* *];
  if not PassesModPFilter(S, t, g, Degs) then return; end if;      // proven: nothing to find here
  s0 := Cputime();
  Z := Zeros(S`FA!t);
  s1 := Cputime();
  for pl in Z do
    if Degree(pl) notin Degs or IsCuspidalPlace(S, pl) then continue; end if;   // never touch large residue fields
    Append(~pls, <pl, [* Evaluate(g, pl) : g in L`basisfuns *]>);
  end for;
  s2 := Cputime();
  if s2 - s0 gt 1 then printf "SLOW_FACTOR deg %o: zeros %o s (place degrees %o), evaluations %o s\n", Degree(t), s1-s0, [Degree(z) : z in Z], s2-s1; end if;
  cache[key] := pls;
end procedure;

// Non-cuspidal places of degree <= Dmax at which f = c for some c in Cs, where f is the unit
// with coordinates e.  Uses the norm to the rational function field: a place of degree d has a
// base coordinate of degree dividing d, so only the factors of degree <= Dmax of the numerator
// of Norm(f - c) = +-chi_f(c) can carry such places.  chi_f is computed once.  Places at
// infinity are handled once in the driver.  res: list of <c, place>.
procedure LowDegreeZeros(S, L, e, f, Cs, Degs, ~cache, ~res, ~timers)
  // Degs: set of target place degrees (constant for the run: the cache is keyed by factor only)
  // timers: [chi, factor, places] cumulative seconds
  Dmax := Max(Degs);
  s0 := Cputime();
  chi := CharacteristicPolynomial(f);      // over the base field Q(v)
  timers[1] +:= Cputime(s0);
  res := [* *];
  for c in Cs do
    s0 := Cputime();
    nm := Evaluate(chi, c);
    if nm eq 0 then continue; end if;
    num := Numerator(nm);
    fac := Factorization(num);
    timers[2] +:= Cputime(s0);
    for t in fac do
      if Degree(t[1]) gt Dmax then continue; end if;
      s0 := Cputime();
      pls := [* *];
      PlacesAboveFactor(S, L, t[1], f - c, Degs, ~cache, ~pls);
      timers[3] +:= Cputime(s0);
      for x in pls do
        pl := x[1]; if Degree(pl) notin Degs then continue; end if;
        val := Parent(x[2][1])!1;
        for j in [1..#e] do if e[j] ne 0 then val *:= x[2][j]^e[j]; end if; end for;
        if val eq c then Append(~res, <c, pl>); end if;
      end for;
    end for;
  end for;
end procedure;

// values of the units U (pairs <w, e>) at the place pl; returns those that are rational
function ValuesAtPlace(S, L, U, pl)
  vals := [* Evaluate(g, pl) : g in L`basisfuns *];
  out := [];
  for t in U do
    e := t[2]; x := Parent(vals[1])!1;
    for i in [1..#e] do if e[i] ne 0 then x *:= vals[i]^e[i]; end if; end for;
    ok, r := IsCoercible(Rationals(), x);
    if ok then Append(~out, <UnitDegree(S, t[1]), e, r>); end if;
  end for;
  return out;
end function;

// data at a non-cuspidal place
function EPQAtPlace(S, pl)
  bb := Evaluate(S`b, pl); cc := Evaluate(S`c, pl);
  K := Parent(bb);
  if Type(K) eq FldNum then                       // relative extensions confuse Order(): go absolute
    Kabs := AbsoluteField(K); bb := Kabs!bb; cc := Kabs!cc;
  else Kabs := K; end if;
  if S`M eq 2 then
    E := EllipticCurve([0, cc, 0, (1-bb-cc)*bb, 0]); P := E![0,0]; Q := E![bb,bb];
  elif S`M eq 1 then
    E := EllipticCurve([1-cc, -bb, -bb, 0, 0]); Q := E![0,0]; P := Q;
  elif S`fmodel then
    E := EllipticCurve([Kabs!Evaluate(a, pl) : a in aInvariants(S`E)]);
    P := E![Kabs!Evaluate(x, pl) : x in [S`P[1], S`P[2]]];       // (0,0), order M
    x0 := Kabs!Evaluate(S`FA!S`Q[1], pl);
    a1, a2, a3, a4, a6 := Explode(aInvariants(E));
    D := (a1*x0 + a3)^2 + 4*(x0^3 + a2*x0^2 + a4*x0 + a6);
    issq, sq := IsSquare(D);
    if not issq then                                   // Q lives over the quadratic extension L(sqrt D)
      L2 := AbsoluteField(ext< Kabs | Polynomial([Kabs | -D, 0, 1]) >);
      E := BaseChange(E, L2); P := E!P; Kabs := L2; x0 := L2!x0; a1 := L2!a1; a3 := L2!a3;
      issq, sq := IsSquare(L2!D); assert issq;
    end if;
    Q := E![x0, (-(a1*x0 + a3) + sq)/2];
  else
    E := EllipticCurve([Kabs!Evaluate(a, pl) : a in aInvariants(S`E)]);
    P := E![Kabs!Evaluate(x, pl) : x in [S`P[1], S`P[2]]]; Q := E![Kabs!Evaluate(x, pl) : x in [S`Q[1], S`Q[2]]];
  end if;
  return E, P, Q, Kabs;
end function;

procedure ReportPlace(S, pl, tag)
  E, P, Q, K := EPQAtPlace(S, pl);
  oQ := Order(Q); oP := Order(P);
  j := jInvariant(E);
  mj := MinimalPolynomial(j);
  Kabs := K;
  printf "%o deg=%o absdeg=%o ordQ=%o ordP=%o degj=%o jminpoly=%o\n", tag, Degree(pl), Type(Kabs) eq FldRat select 1 else Degree(Kabs), oQ, oP, Degree(mj), mj;
  if Type(Kabs) eq FldRat then printf "%o field=Q\n", tag;
  else printf "%o field=%o disc=%o\n", tag, DefiningPolynomial(Kabs), Discriminant(MaximalOrder(Kabs)); end if;
  printf "%o b=%o c=%o\n", tag, Evaluate(S`b, pl), Evaluate(S`c, pl);
  // P^1-isolation: l(v) = 1 iff no function of degree <= deg v has all its poles at v;
  // for a rank-0 Jacobian this is equivalent to v being an isolated point.
  l := Dimension(RiemannRochSpace(1*pl));
  printf "%o l(v)=%o %o\n", tag, l, l eq 1 select "P1-ISOLATED" else "IN_A_PENCIL";
end procedure;

// The place of FA where (b, c) = (b0, c0), for b0, c0 in a number field K (or Q) of degree d.
// Among the low-degree zeros of minpoly_Q(b0)(b) (found via the norm, so that no high-degree
// place is ever constructed), the one at which minpoly_{Q(b0)}(c0)(b, c) vanishes.
function PlaceFromBC(S, b0, c0)
  K := Parent(b0);
  d := Type(K) eq FldRat select 1 else Degree(K);
  mb := MinimalPolynomial(b0, Rationals());
  if Type(K) eq FldRat then
    g := S`c - c0;
  else
    Kb := sub< K | b0 >;
    mc := MinimalPolynomial(c0, Kb);                 // coefficients in Kb = Q(b0)
    g := S`FA!0;
    for i in [0..Degree(mc)] do
      ai := Eltseq(Kb!Coefficient(mc, i));           // coordinates w.r.t. powers of b0
      aib := &+[ ai[j]*S`b^(j-1) : j in [1..#ai] ];
      g +:= aib * S`c^i;
    end for;
  end if;
  // direct version (no basis-unit cache): low-degree factors of the norm of mb(b)
  h := Evaluate(mb, S`b);
  nm := Norm(h); fac := Factorization(Numerator(nm));
  cands := [];
  for t in fac do
    if Degree(t[1]) gt d then continue; end if;
    for pl in Zeros(S`FA!t[1]) do
      if Degree(pl) le d and not IsCuspidalPlace(S, pl) and Valuation(h, pl) gt 0 and Valuation(g, pl) gt 0 then Append(~cands, pl); end if;
    end for;
  end for;
  assert #cands eq 1;
  return cands[1];
end function;

/* ---- candidates over an arbitrary field via a hand-coded group law ---------------------------
   The same candidate list as CandidateUnits, but computed from (b, c) in any field with the
   addition law of y^2 = x^3 + c x^2 + (1-b-c) b x (M = 2) / Tate normal form (M = 1) written out,
   so that it can be run over a Laurent series field: expanding b and c at a cusp is cheap, and
   then every candidate's expansion (leading coefficient AND valuation) follows by series
   arithmetic, whereas Evaluate/Expand of the candidates themselves at the deep cusps is slow. */

// group law on y^2 + a1 xy + a3 y = x^3 + a2 x^2 + a4 x + a6; points as [x, y] (affine, never O)
function AddPts(a, P1, P2)
  a1, a2, a3, a4, a6 := Explode(a);
  x1, y1 := Explode(P1); x2, y2 := Explode(P2);
  if x1 eq x2 then
    assert y1 eq y2;    // P1 = -P2 never happens for the points we use on Y
    lam := (3*x1^2 + 2*a2*x1 + a4 - a1*y1) / (2*y1 + a1*x1 + a3);
  else
    lam := (y2 - y1) / (x2 - x1);
  end if;
  nu := y1 - lam*x1;
  x3 := lam^2 + a1*lam - a2 - x1 - x2;
  y3 := -(lam + a1)*x3 - nu - a3;
  return [x3, y3];
end function;

// candidates from (b, c): returns list of <label, value>; identical labels/order to CandidateUnits
function CandidateUnitsFrom(b, c, N, M)
  F := Parent(b); h := N div 2;
  if M eq 2 then a := [F | 0, c, 0, (1-b-c)*b, 0]; Q := [b, b]; P := [F | 0, 0];
  else a := [F | 1-c, -b, -b, 0, 0]; Q := [F | 0, 0]; P := Q; end if;
  Delta := M eq 2 select 16*b^2*(1-b-c)^2*(4*b^2 + 4*b*c - 4*b + c^2) else b^3*(16*b^2 + (1 - 20*c - 8*c^2)*b + c*(c-1)^3);
  xs := []; R := Q;
  for k in [1..h] do Append(~xs, R[1]); if k lt h then R := AddPts(a, R, Q); end if; end for;
  xps := [];
  if M eq 2 then
    R := P;
    for k in [0..h] do Append(~xps, R[1]); if k lt h then R := AddPts(a, R, Q); end if; end for;
  end if;
  units := [* *];
  Append(~units, <"b", b>); Append(~units, <"c", c>);
  Append(~units, <"Delta", Delta>);
  if M eq 2 then
    Append(~units, <"1-b-c", 1 - b - c>);
    Append(~units, <"disc2", 4*b^2 + 4*b*c - 4*b + c^2>);
    for k in [1..h] do Append(~units, <Sprintf("x(%oQ)", k), xs[k]>); end for;
    for k in [1..h] do if xps[k+1] ne 0 then Append(~units, <Sprintf("x(P+%oQ)", k), xps[k+1]>); end if; end for;
  end if;
  for k in [1..h] do for l in [k+1..h] do
    Append(~units, <Sprintf("x(%oQ)-x(%oQ)", k, l), xs[k] - xs[l]>);
  end for; end for;
  if M eq 2 then
    for k in [1..h] do for l in [1..h] do
      Append(~units, <Sprintf("x(P+%oQ)-x(%oQ)", k, l), xps[k+1] - xs[l]>);
    end for; end for;
    for k in [1..h] do for l in [k+1..h] do
      Append(~units, <Sprintf("x(P+%oQ)-x(P+%oQ)", k, l), xps[k+1] - xps[l+1]>);
    end for; end for;
  end if;
  return units;
end function;

// leading coefficients and valuations of all candidates at the cusp C via Laurent expansions of
// b and c (precision raised until every leading term is determined)
function CandidateLeadingTerms(S, C : Prec := 60)
  prec := Prec;
  repeat
    Cpl, mp := Completion(S`FA, C : Precision := prec);
    bs := mp(S`b); cs := mp(S`c);
    units := CandidateUnitsFrom(bs, cs, S`N, S`M);
    ok := true; lcs := [* *]; vals := [];
    for u in units do
      x := u[2];
      if x eq 0 or RelativePrecision(x) le 0 then ok := false; break; end if;   // 0 or O(t^n): undetermined
      v := Valuation(x); Append(~vals, v); Append(~lcs, Coefficient(x, v));
    end for;
    if not ok then prec *:= 2; if prec gt 4000 then error "cusp expansions: precision blow-up"; end if; end if;
  until ok;
  return lcs, vals, [u[1] : u in units];
end function;

/* ---------------- cusp-value data for the "f - f(C)" search ----------------

   Heuristic (Tate curve; verified on the quintic point of X_1(2,18), notes/):
   if a non-cuspidal point v reduces, at a prime of its field above l, to the cusp C, and f is a
   unit with v_C(f) = 0, then ord_l(f(v)) = ord_P(f(C))/e(P|l) for the corresponding prime P of
   Q(C).  So for f(v) rational, f(v) = +- prod_l l^{a_l} with a_l taken from the cusp values.
   For every cusp C and basis unit g_j we store the leading coefficient
       lc_C(g_j) = (g_j / t_C^{v_C(g_j)})(C)  in Q(C)      (t_C a fixed uniformiser)
   and the factorisation of the ideal it generates; for a unit f = prod g_j^{e_j} with
   v_C(f) = 0 we then have f(C) = prod lc_C(g_j)^{e_j} exactly, and the exponents are linear.  */

CuspDataRec := recformat< primes, ells, es, ordmat, lcs, isQ, gens >;
// primes: prime ideals P of Q(C) above the primes l in Lset (rational primes when Q(C) = Q);
// ells: the primes l below; es: ramification indices; ordmat[j][k] = ord_{P_k}(lc_C(g_j));
// lcs: the lc values (only for degree-1 cusps, i.e. Q(C) = K); gens: generators of the P_k
// (K has class number 1 for the cyclotomic fields used) -- the candidate values are
// (root of unity) * prod gens[k]^{a_k}.

function CuspValueData(S, L, Lset)
  data := [* *];
  rk := Nrows(L`B); ng := #L`gens;
  K := S`K; isQfield := Type(K) eq FldRat;
  for i in [1..#S`cusps] do
    C := S`cusps[i]; t := UniformizingElement(C);
    KC := ResidueClassField(C);
    isQ := Degree(C) eq 1;                        // residue field = K
    // leading coefficients of the generators (ratios of candidates, degree ~ gonality):
    // Evaluate(g * t^-v, C) costs 0-6 s per pair on 2n = 22, whereas Completion/Expand at the
    // deep cusps can take > 10 min (notes/02).  Basis lc's: products with T (small).
    genlcs := [* *];
    for k in [1..ng] do
      vk := L`V[k, i];
      Append(~genlcs, KC!Evaluate(L`gens[k] * t^(-vk), C));
    end for;
    lcs := [* *];
    for j in [1..rk] do
      x := KC!1;
      for k in [1..ng] do if L`T[j,k] ne 0 then x *:= genlcs[k]^L`T[j,k]; end if; end for;
      Append(~lcs, x);
    end for;
    if isQ and isQfield then
      primes := Lset; ells := Lset; es := [1 : p in primes]; gens := [Rationals()!p : p in primes];
      ordmat := [ [Valuation(x, p) : p in primes] : x in lcs ];
    else
      // KC is K (degree-1 cusp over a number field) or a proper extension of K (M <= 2, full mode)
      OC := MaximalOrder(KC);
      primes := []; ells := []; es := []; gens := [];
      for l in Lset do
        for dp in Decomposition(OC, l) do
          Append(~primes, dp[1]); Append(~ells, l); Append(~es, dp[2]);
          if isQ then                       // KC = K: the candidate values are built from generators of the primes of K
            ok, gen := IsPrincipal(dp[1]); Append(~gens, ok select K!gen else K!0);
          elif isQfield then                // K = Q, Q(C) a proper extension: exponent of the rational prime l
            Append(~gens, K!l);
          else                              // K a number field and Q(C) a proper extension: not used
            Append(~gens, K!0);
          end if;
        end for;
      end for;
      ordmat := [ [Valuation(x, P) : P in primes] : x in lcs ];
      if not isQ then lcs := [* *]; else lcs := [* K!x : x in lcs *]; end if;   // exact values (in K) only at degree-1 cusps
    end if;
    Append(~data, rec< CuspDataRec | primes := primes, ells := ells, es := es, ordmat := ordmat, lcs := lcs, isQ := isQ, gens := gens >);
  end for;
  return data;
end function;

// candidate values c in K of the unit with coordinates e (w = e*B its cusp valuations), from the
// cusps where w_i = 0: c = zeta * prod_k gens_k^{a_k} with a_k in {ord_{P_k}(f(C))/e_k} u {0}
// (Tate-curve heuristic, notes/01), plus the exact values f(C) at degree-1 cusps; zeta runs over
// the roots of unity of K.  Returns a sequence of elements of K (no signs/roots of unity).
function CandidateValues(S, L, cdata, e, w, Lset)
  K := S`K;
  A := AssociativeArray();          // key: <ell, index of P above ell> -> set of exponents
  gensK := AssociativeArray();
  exact := {};
  for i in [1..#cdata] do
    if w[i] ne 0 then continue; end if;
    cd := cdata[i];
    if cd`isQ then
      val := &*[ K | cd`lcs[j]^e[j] : j in [1..#e] | e[j] ne 0 ];
      Include(~exact, val);
    end if;
    for k in [1..#cd`primes] do
      l := cd`ells[k];
      if l notin Lset then continue; end if;
      if cd`gens[k] eq 0 then continue; end if;          // non-principal prime: skip
      o := &+[ e[j]*cd`ordmat[j][k] : j in [1..#e] ];
      if o mod cd`es[k] ne 0 then continue; end if;
      key := Sprint(<l, cd`gens[k]>);
      if not IsDefined(A, key) then A[key] := {0}; gensK[key] := cd`gens[k]; end if;
      Include(~A[key], o div cd`es[k]);
    end for;
  end for;
  vals := {K | 1};
  for key in Keys(A) do
    g := gensK[key];
    vals := { x * g^a : x in vals, a in A[key] };
  end for;
  vals join:= exact;
  return Setseq(vals);
end function;



