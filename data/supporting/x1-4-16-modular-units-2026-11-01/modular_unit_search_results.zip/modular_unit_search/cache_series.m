SetColumns(0);
N:=StringToInteger(N);
load "./standalone_lib_v4.m";
function SeriesValues(S,C)
 prec:=60;
 while prec le 7680 do
  try
   Cp,mp:=Completion(S`FA,C:Precision:=prec);
   us:=CandidateUnitsFrom(mp(S`b),mp(S`c),S`N,S`M);
   if &and[u[2] ne 0 and RelativePrecision(u[2]) gt 0:u in us] then
    return [Valuation(u[2]):u in us],[u[1]:u in us],prec;
   end if;
  catch err
   dummy:=0;
  end try;
  prec*:=2;
 end while;
 error "Series precision exhausted";
end function;
try
 S:=Setup(N,2:Field:=GF(3));
 weights:=[Degree(C):C in S`cusps];bycusp:=[];precs:=[];labels:=[];
 for k in [1..#S`cusps] do
  w,labels,prec:=SeriesValues(S,S`cusps[k]);
  Append(~bycusp,w);Append(~precs,prec);
  assert w[1] eq Valuation(S`b,S`cusps[k]);
  assert w[2] eq Valuation(S`c,S`cusps[k]);
  assert w[3] eq Valuation(S`Delta,S`cusps[k]);
  printf "CUSP_SERIES k=%o of=%o precision=%o cpu=%o\n",k,#S`cusps,prec,Cputime();
 end for;
 vecs:=[[bycusp[k][j]:k in [1..#bycusp]]:j in [1..#labels]];
 oks:=[];
 for j in [1..#labels] do
  w:=vecs[j];pos:=&+[Integers()|w[k]*weights[k]:k in [1..#w]|w[k] gt 0];
  neg:=&+[Integers()|-w[k]*weights[k]:k in [1..#w]|w[k] lt 0];
  if labels[j] ne "c" then assert pos eq neg and pos gt 0;end if;
  Append(~oks,labels[j] ne "c" and pos eq neg and pos gt 0);
 end for;
 path:=Sprintf("./cusp_cache_2_%o_p3.txt",N);
 Write(path,Sprintf("<%o,%o,%o,%o>",weights,labels,vecs,oks):Overwrite:=true);
 printf "CUSP_CACHE_DONE file=%o candidates=%o cusps=%o cpu=%o\n",path,#labels,#weights,Cputime();
catch err
 printf "CUSP_CACHE_FAILED %o\n",err;
end try;
quit;
