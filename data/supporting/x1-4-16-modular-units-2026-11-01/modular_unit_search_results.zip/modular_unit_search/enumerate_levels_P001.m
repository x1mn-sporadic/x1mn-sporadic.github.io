SetColumns(0);
load "./P001.m";
try
 oldE:=E;oldP:=P;oldQ:=Q;j0:=jInvariant(E);ad:=Degree(L);
 if WeilPairing(P,4*Q,4) eq base_i then P0:=P;else P0:=-P;end if;
 assert WeilPairing(P0,4*Q,4) eq base_i;
 a1,a2,a3,a4,a6:=Explode(ai);triples:=[];
 for bb,cc in [0..3] do for dd in [1,5,9,13] do
  PP:=P0+bb*(4*Q);QQ:=cc*P0+dd*Q;
  xp:=PP[1];yp:=PP[2];
  slope:=(3*xp^2+2*a2*xp+a4-a1*yp)/(2*yp+a1*xp+a3);
  scale:=a1+2*slope;assert scale ne 0;
  a2p:=a2+3*xp-slope^2-a1*slope;
  a3p:=a3+a1*xp+2*yp;
  a4p:=a4+2*a2*xp+3*xp^2-slope*a3p-a1*yp;
  assert a4p eq 0 and a3p eq scale*a2p;
  par:=a2p/scale^2;
  xq:=(QQ[1]-xp)/scale^2;yq:=(QQ[2]-yp-slope*(QQ[1]-xp))/scale^3;
  En:=EllipticCurve([L|1,par,par,0,0]);Pn:=En![0,0];Qn:=En![xq,yq];
  assert 4*Pn eq En!0 and 2*Pn ne En!0;
  assert 16*Qn eq En!0 and 8*Qn ne En!0;
  assert WeilPairing(Pn,4*Qn,4) eq base_i;
  assert jInvariant(En) eq j0;
  tup:=<par,xq,yq>;assert tup notin triples;
  full:=false;
  for k in [1..20] do
   if Degree(MinimalPolynomial(par+k*xq+k^2*yq+k^3*base_i)) eq ad then full:=true;break;end if;
  end for;
  assert full;Append(~triples,tup);
 end for;end for;
 assert #triples eq 64;
 autos:=[aa:aa in Automorphisms(L)|aa(base_i) eq base_i and aa(j0) eq j0];
 orbits:=[];used:={Integers()|};
 for k in [1..#triples] do
  if k in used then continue;end if;
  tt:=triples[k];orb:={Index(triples,<aa(tt[1]),aa(tt[2]),aa(tt[3])>):aa in autos};
  assert 0 notin orb and #orb eq #autos;
  Append(~orbits,Sort(Setseq(orb)));used join:=orb;
 end for;
 assert #used eq 64;
 data:=[<Eltseq(tt[1]),Eltseq(tt[2]),Eltseq(tt[3])>:tt in triples];
 Write("./level_structures_P001.m",Sprintf("field_polynomial:=%o;\nbase_i_coefficients:=%o;\nstructures:=%o;\nclosed_orbits:=%o;\n",Eltseq(DefiningPolynomial(L)),Eltseq(base_i),data,orbits):Overwrite:=true);
 printf "LEVEL_ENUM_DONE geometric_markings=64 automorphisms_over_j_and_Qi=%o closed_points=%o relative_degree=%o absolute_degree=%o\n",#autos,#orbits,relative_degree,ad;
catch err
 printf "LEVEL_ENUM_FAILED %o\n",err;
end try;
quit;
