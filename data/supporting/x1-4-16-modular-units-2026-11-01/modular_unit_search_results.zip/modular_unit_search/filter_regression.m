SetColumns(0);
// A genuine degree-two characteristic-zero fiber splits modulo 7.
Q<t>:=FunctionField(Rationals());R<U>:=PolynomialRing(Q);
F<a>:=FunctionField(U^2-t);
chi:=CharacteristicPolynomial(F!(t-2));
assert Numerator(Evaluate(chi,0)) eq (t-2)^2;
S<x>:=PolynomialRing(Rationals());assert IsIrreducible(x^2-2);
Fp:=GF(7);Rp<z>:=PolynomialRing(Fp);h:=z^2-2;
assert [Degree(q[1]):q in Factorization(h)] eq [1,1];
old_accepts:=2 in {Degree(q[1]):q in Factorization(h)};
new_accepts:=Degree(h) ge 2;
assert not old_accepts and new_accepts;
printf "FILTER_REGRESSION_DONE: genuine quadratic fiber retained despite split reduction.\n";
quit;
