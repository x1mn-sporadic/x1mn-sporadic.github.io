SetColumns(0);
M:=StringToInteger(M);N:=StringToInteger(N);
if not assigned MaxUnits then MaxUnits:=500;else MaxUnits:=StringToInteger(MaxUnits);end if;
if not assigned Bound then Bound:=60;else Bound:=StringToInteger(Bound);end if;
if not assigned Tag then Tag:="v3";end if;
SetMemoryLimit(12*10^9);
load "./standalone_lib_v3.m";

function EvalCoefficient(cf,vv,L)
 return Evaluate(Numerator(cf),vv)/Evaluate(Denominator(cf),vv);
end function;
function EvalFunction(f,uu,vv,L)
 return &+[L|EvalCoefficient(cs[j],vv,L)*uu^(j-1):j in [1..#cs]] where cs:=Eltseq(f);
end function;

procedure SaveRaw(S,E,P,Q,L,u,v,dd,idx,c,unitdegree,~count,~seen)
 assert S`N*Q eq E!0 and &and[(S`N div p)*Q ne E!0:p in PrimeDivisors(S`N)];
 assert S`M*P eq E!0 and &and[(S`M div p)*P ne E!0:p in PrimeDivisors(S`M)];
 assert #{a*P+b*((S`N div S`M)*Q):a,b in [0..S`M-1]} eq S`M^2;
 assert Discriminant(E) ne 0;
 ad:=Degree(L);assert ad eq dd*(S`M eq 2 select 1 else 2);
 ii:=S`M eq 2 select L!0 else L!S`zeta;
 full:=false;
 for k in [1..12] do if Degree(MinimalPolynomial(u+k*v+k^2*ii)) eq ad then full:=true;break;end if;end for;
 assert full;
 jp:=MinimalPolynomial(jInvariant(E));key:=Sprint(Eltseq(jp));
 if key in seen then printf "REPEATED_J unit=%o relative_degree=%o\n",idx,dd;return;end if;
 Include(~seen,key);count+:=1;
 path:=Sprintf("./point_%o_%o_%o_%o.m",S`M,S`N,Tag,count);
 str:=Sprintf("R<x>:=PolynomialRing(Rationals());\nL<a>:=NumberField(R!%o);\n",Eltseq(DefiningPolynomial(L)));
 str cat:="ai:=[L|";
 for j in [1..5] do str cat:=Sprintf("L!%o%o",Eltseq(aInvariants(E)[j]),j eq 5 select "];\n" else ",");end for;
 str cat:="E:=EllipticCurve(ai);\n";
 for xy in [<"P",P>,<"Q",Q>] do str cat:=Sprintf("%o:=E![L!%o,L!%o];\n",xy[1],Eltseq(xy[2][1]),Eltseq(xy[2][2]));end for;
 str cat:=Sprintf("model_u:=L!%o;\nmodel_v:=L!%o;\nbase_i:=L!%o;\nM:=%o;N:=%o;relative_degree:=%o;\n",Eltseq(u),Eltseq(v),Eltseq(ii),S`M,S`N,dd);
 Write(path,str:Overwrite:=true);
 printf "POINT_SAVED file=%o relative_degree=%o absolute_degree=%o j_degree=%o unit_index=%o unit_degree=%o c=%o\n",path,dd,ad,Degree(jp),idx,unitdegree,c;
 printf "POINT_JPOLY %o\n",jp;
end procedure;

procedure AnalyzeFactor(S,t,g,dg,idx,c,ud,~count,~seen,~exceptions)
 ee:=Degree(t);K:=S`K;
 try
  if ee eq 1 then F:=K;vv:=-Coefficient(t,0)/Coefficient(t,1);
  else F<vv>:=NumberField(t);end if;
  RF<T>:=PolynomialRing(F);
  fpoly:=RF![EvalCoefficient(cf,vv,F):cf in Coefficients(DefiningPolynomial(S`FA))];
  gpoly:=RF![EvalCoefficient(cf,vv,F):cf in Eltseq(g)];
  assert Degree(fpoly) eq Degree(S`FA);
  h:=GCD(fpoly,gpoly);
  for hh in Factorization(h) do
   rr:=Degree(hh[1]);dd:=ee*rr;if dd notin dg then continue;end if;
   if rr eq 1 then F1:=F;uu:=-Coefficient(hh[1],0)/Coefficient(hh[1],1);
   else F1<uu>:=NumberField(hh[1]);end if;
   L:=AbsoluteField(F1);u0:=L!uu;v0:=L!vv;
   Ecoef:=[L|EvalFunction(a,u0,v0,L):a in aInvariants(S`E)];
   if Discriminant(EllipticCurve(Ecoef)) eq 0 then continue;end if;
   E:=EllipticCurve(Ecoef);
   P:=E![EvalFunction(S`P[j],u0,v0,L):j in [1,2]];
   Q:=E![EvalFunction(S`Q[j],u0,v0,L):j in [1,2]];
   mu:=EvalFunction(S`toFA(S`FF.1),u0,v0,L);mv:=EvalFunction(S`toFA(S`FF.2),u0,v0,L);
   assert EvalFunction(g,u0,v0,L) eq 0;
   SaveRaw(S,E,P,Q,L,mu,mv,dd,idx,c,ud,~count,~seen);
  end for;
 catch err
  exceptions+:=1;
  printf "EXCEPTIONAL_FIBER unit=%o c=%o base_degree=%o factor=%o error=%o\n",idx,c,ee,t,err;
 end try;
end procedure;

t0:=Cputime();
try
 Degs:=M eq 2 select {11} else {6,7};
 S:=Setup(N,M:NoCusps:=true,RationalCuspsOnly:=true);S`filterdata:=FilterData(S);
 printf "SETUP M=%o N=%o genus=%o targets=%o time=%o\n",M,N,Genus(S`FA),Degs,Cputime(t0);
 K:=S`K;
 if M eq 2 then Cs:=[K|s*2^e:s in [1,-1],e in [-4..4]];
 else Cs:=Setseq({K|S`zeta^s*(1+S`zeta)^e:s in [0..3],e in [-8..8]});end if;
 units:=CandidateUnits(S);L,S:=UnitLatticeR(S,units:ModP:=(M eq 2 select 3 else 101));
 U:=ShortUnits(S,L,Bound:MaxCount:=MaxUnits);
 printf "SEARCH_START units=%o constants=%o distribution=%o time=%o\n",#U,#Cs,[<d,#[x:x in U|UnitDegree(S,x[1]) eq d]>:d in Sort(Setseq({UnitDegree(S,x[1]):x in U}))],Cputime(t0);
 count:=0;seen:={};tested:=0;fibers:=0;exceptions:=0;
 for idx in [1..#U] do
  degree:=UnitDegree(S,U[idx][1]);dg:={d:d in Degs|d lt degree};if #dg eq 0 then continue;end if;
  printf "UNIT_BEGIN index=%o degree=%o time=%o\n",idx,degree,Cputime(t0);
  f:=UnitFromExponents(L,U[idx][2]);chi:=CharacteristicPolynomial(f);tested+:=1;
  for c in Cs do
   nm:=Evaluate(chi,c);if nm eq 0 then continue;end if;
   fac:=Factorization(Numerator(nm));fibers+:=1;
   for t in fac do
    if exists{d:d in dg|d mod Degree(t[1]) eq 0} and PassesModPFilter(S,t[1],f-c,dg) then
     AnalyzeFactor(S,t[1],f-c,dg,idx,c,degree,~count,~seen,~exceptions);
    end if;
   end for;
  end for;
  printf "PROGRESS units=%o fibers=%o j_orbits=%o exceptional_factors=%o time=%o\n",tested,fibers,count,exceptions,Cputime(t0);
 end for;
 printf "SEARCH_DONE M=%o N=%o units=%o fibers=%o j_orbits=%o exceptional_factors=%o time=%o\n",M,N,tested,fibers,count,exceptions,Cputime(t0);
catch err
 printf "SEARCH_FAILED M=%o N=%o error=%o time=%o\n",M,N,err,Cputime(t0);
end try;
quit;
