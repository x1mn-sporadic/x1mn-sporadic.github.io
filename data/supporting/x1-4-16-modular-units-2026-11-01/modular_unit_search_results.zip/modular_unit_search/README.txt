Four verified non-CM j-orbits on X_1(4,16), giving 192 sporadic closed points over Q(i).

Start with verified_points.csv for fields, degrees and representative families; closed_points.csv lists the 192 closed points. P001.m through P004.m define exact fields, curves and marked points. verification.txt gives the proof and replay instructions. search_summary.json and search_coverage.csv record the bounded searches in all four requested ranges.

Run verification from this directory with Magma 2.30-1, with startup customizations disabled: magma -n -b verify_P001.m
All four representative verifiers, their field checks, their full-torsion bounds and their level-structure orbit enumerations passed. The helper reconstructs any of the 192 saved closed points.

Discovery sources and completed logs are included for reproducibility. Rerun searches in a fresh copy and choose a new Tag to preserve the supplied evidence. Cusp caches are supplied in their quoted-label format. To regenerate one, run cache_series.m with N:=26,28,32 and then quote_cache_labels.py. The cache valuation matrices were computed with adaptive Laurent precision and checked against b, c and Delta at every cusp.

Models are from Sutherland's optimized X_1(m,mn) equations, following Derickx-Sutherland (2017), imported from the local research cache: https://math.mit.edu/~drew/X1mn.html
