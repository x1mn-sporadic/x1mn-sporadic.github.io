// Run from this directory, e.g.
// magma -n -b Family:=P003 Index:=1 construct_closed_point.m
SetColumns(0);
if not assigned Family then Family:="P001";end if;
if not assigned Index then Index:=1;elif Type(Index) eq MonStgElt then Index:=StringToInteger(Index);end if;
assert Family in {"P001","P002","P003","P004"};
for line in Split(Read("level_structures_" cat Family cat ".m"),";") do
 if #line eq 0 or not ":=" in line then continue;end if;
 kv:=Split(line,":=");key:=Trim(kv[1]);val:=kv[2];
 if key eq "field_polynomial" then field_polynomial:=eval val;
 elif key eq "base_i_coefficients" then base_i_coefficients:=eval val;
 elif key eq "structures" then structures:=eval val;
 elif key eq "closed_orbits" then closed_orbits:=eval val;
 end if;
end for;
assert Index ge 1 and Index le #closed_orbits;
R<x>:=PolynomialRing(Rationals());L<a>:=NumberField(R!field_polynomial);
base_i:=L!base_i_coefficients;
entry:=structures[closed_orbits[Index][1]];
A:=L!entry[1];E:=EllipticCurve([L|1,A,A,0,0]);P:=E![0,0];Q:=E![L!entry[2],L!entry[3]];
assert 4*P eq E!0 and 2*P ne E!0;
assert 16*Q eq E!0 and 8*Q ne E!0;
assert WeilPairing(P,4*Q,4) eq base_i;
full:=false;
for k in [1..20] do
 if Degree(MinimalPolynomial(A+k*Q[1]+k^2*Q[2]+k^3*base_i)) eq Degree(L) then full:=true;break;end if;
end for;
assert full;
printf "CONSTRUCTED %o.%o absolute_degree=%o relative_degree=%o\n",Family,Index,Degree(L),Degree(L) div 2;
printf "Field polynomial: %o\n",DefiningPolynomial(L);
printf "Curve: %o\nP=%o\nQ=%o\n",E,P,Q;
quit;
