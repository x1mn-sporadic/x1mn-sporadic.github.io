SetColumns(0);
load "./P004.m";
g0:=((P+8*Q)[1]-(2*P+4*Q)[1])/((P+2*Q)[1]-(P+8*Q)[1]);
assert g0 eq -1/2 or g0 eq -2;
printf "UNIT12_VALUE value=%o invert=%o\n",g0,g0 eq -2;
quit;
