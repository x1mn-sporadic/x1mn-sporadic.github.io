from pathlib import Path
import json, re
for p in Path('.').glob('cusp_cache_2_*_p3.txt'):
    s=p.read_text()
    m=re.match(r'^(<\[.*?\],)\[(.*?)\],',s,re.S)
    if not m:
        raise ValueError(p)
    if '"' in m[2]:
        continue
    labels=[x.strip() for x in m[2].split(',')]
    assert labels[:3]==['b','c','Delta']
    p.write_text(m[1]+json.dumps(labels)+','+s[m.end():])
