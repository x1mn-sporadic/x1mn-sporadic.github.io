SetColumns(0);
load "./P002.m";
SetColumns(0);
SetMemoryLimit(6*10^9);
try
 assert IsIrreducible(DefiningPolynomial(L));
 ad:=Degree(L);
 assert ad eq relative_degree*(M eq 2 select 1 else 2);
 if M eq 4 then assert base_i^2 eq -1;end if;
 assert N*Q eq E!0 and &and[(N div p)*Q ne E!0:p in PrimeDivisors(N)];
 assert M*P eq E!0 and &and[(M div p)*P ne E!0:p in PrimeDivisors(M)];
 assert #{a*P+b*((N div M)*Q):a,b in [0..M-1]} eq M^2;
 assert Discriminant(E) ne 0;

 // Re-enter the affine model and moduli parametrization independently.
 u:=model_u;v:=model_v;i:=base_i;
 model:=Sprintf("./models/X1_%o_%o.txt",M,N);
 for line in Split(Read(model),"\n") do
  if #line eq 0 or not ":=" in line then continue;end if;
  kv:=Split(line,":=");key:=Trim(kv[1]);val:=Split(kv[2],";")[1];
  if key in {"X","Xi"} then model_value:=eval val;
  elif key eq "q" then q:=eval val;
  elif key eq "t" then t:=eval val;
  elif key eq "E" then expected_ai:=eval val;
  elif key eq "P" then expected_Q:=eval val;
  elif key eq "Q" then expected_P:=eval val;
  end if;
 end for;
 assert model_value eq 0;
 if M eq 2 then
  bb:=(t+1)*(q*t+1)/t^2;cc:=(t^2-2*q*t-2)/t^2;
  expected_ai:=[L|0,cc,0,(1-bb-cc)*bb,0];expected_P:=[L|0,0];expected_Q:=[L|bb,bb];
 end if;
 assert aInvariants(E) eq expected_ai and E!expected_P eq P and E!expected_Q eq Q;
 full:=false;primitive_multiplier:=0;
 for k in [1..20] do
  primitive:=model_u+k*model_v+k^2*base_i;
  if Degree(MinimalPolynomial(primitive)) eq ad then full:=true;primitive_multiplier:=k;break;end if;
 end for;
 assert full;
 // The chosen normal forms fix the Weierstrass scaling. Check generation
 // by the actual moduli data, as well as by the affine model coordinates.
 if M eq 2 then
  assert P eq E![0,0] and Q[1] eq Q[2];
  moduli:=[L|ai[2],Q[1]];
 else
  assert P eq E![0,0] and ai[1] eq 1 and ai[2] eq ai[3] and ai[4] eq 0 and ai[5] eq 0;
  eps:=WeilPairing(P,(N div M)*Q,M);
  assert eps in {base_i,-base_i};
  moduli:=[L|ai[2],Q[1],Q[2],eps];
 end if;
 moduli_full:=false;
 for kk in [1..20] do
  zz:=&+[moduli[j]*kk^(j-1):j in [1..#moduli]];
  if Degree(MinimalPolynomial(zz)) eq ad then moduli_full:=true;break;end if;
 end for;
 assert moduli_full;
 printf "VERIFIED_FIELD degree=%o relative_degree=%o polynomial=%o\n",ad,relative_degree,DefiningPolynomial(L);
 printf "VERIFIED_MINIMAL_MODULI_FIELD primitive_multiplier=%o\n",primitive_multiplier;
 printf "VERIFIED_FIELD_GENERATED_BY_ELLIPTIC_LEVEL_DATA\n";
 printf "VERIFIED_MARKED_SUBGROUP invariants=[%o,%o]\n",M,N;

 // Prime-to-residue-characteristic torsion injects under good reduction.
 // Taking bounds prime by prime handles the residue characteristics as well.
 f:=DefiningPolynomial(L);counts:=[];bound:=0;
 for p in PrimesInInterval(5,5000) do
  if M*N mod p eq 0 then continue;end if;
  bad:=exists{r:r in Eltseq(f)|Denominator(r) mod p eq 0};
  if not bad then bad:=exists{r:r in &cat[Eltseq(a):a in aInvariants(E)]|Denominator(r) mod p eq 0};end if;
  if bad then continue;end if;
  F:=GF(p);RF<z>:=PolynomialRing(F);fp:=RF!Eltseq(f);
  if Degree(fp) ne ad or not IsSquarefree(fp) then continue;end if;
  if #Roots(fp) eq 0 then continue;end if;
  for rt in Roots(fp) do
   vals:=[F|Evaluate(RF!Eltseq(a),rt[1]):a in aInvariants(E)];
   try Ep:=EllipticCurve(vals);catch ee continue;end try;
   if Discriminant(Ep) eq 0 then continue;end if;
   order:=#Ep;Append(~counts,<p,order>);
   printf "GOOD_REDUCTION p=%o root=%o group_order=%o\n",p,rt[1],order;
   break;
  end for;
  if #counts lt 2 then continue;end if;
  primes:={Integers()|};for tcount in counts do primes join:=Seqset(PrimeDivisors(tcount[2]));end for;
  bound:=&*[Integers()|ell^Min([Valuation(tc[2],ell):tc in counts|tc[1] ne ell]):ell in primes];
  assert bound mod (M*N) eq 0;
  if bound eq M*N then break;end if;
 end for;
 printf "TORSION_ORDER_BOUND %o\n",bound;
 if bound eq M*N then printf "VERIFIED_FULL_TORSION [%o,%o]\n",M,N;
 else printf "FULL_TORSION_UNRESOLVED subgroup=[%o,%o] upper_order=%o\n",M,N,bound;end if;
 gamma:=M eq 2 select 12 else 8;
 assert relative_degree lt gamma;
 printf "VERIFIED_SPORADIC rank=0 gonality_lower_bound=%o point_degree=%o base=%o\n",gamma,relative_degree,M eq 2 select "Q" else "Q(i)";
 printf "J_MINPOLY %o\n",MinimalPolynomial(jInvariant(E));
 printf "VERIFY_DONE\n";
catch err
 printf "VERIFY_FAILED %o\n",err;
end try;
quit;
