SetColumns(0);
load "./point_4_16_raw_2.m";
f0:=(P[1]-(2*P+Q)[1])/((2*Q)[1]-P[1]);
cv:=-1-base_i;
assert f0 eq cv or f0 eq 1/cv;
printf "UNIT_VALUE point=2 equals_c=%o equals_inverse_c=%o\n",f0 eq cv,f0 eq 1/cv;
quit;
